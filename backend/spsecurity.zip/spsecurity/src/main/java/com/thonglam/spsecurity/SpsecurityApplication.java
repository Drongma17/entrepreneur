package com.thonglam.spsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpsecurityApplication.class, args);
	}
}
